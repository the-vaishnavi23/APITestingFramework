package com.example.restbooker.tests;

import com.example.restbooker.client.AuthClient;
import com.example.restbooker.client.BookingClient;
import com.example.restbooker.core.BaseTest;
import com.example.restbooker.model.Booking;
import com.example.restbooker.model.Booking.BookingDates;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;

public class BookingCrudTest extends BaseTest {

    private BookingClient bookingClient;
    private AuthClient authClient;
    private String token;

    @BeforeClass
    public void init() {
        bookingClient = new BookingClient();
        authClient = new AuthClient();
        token = authClient.createToken(getUsername(), getPassword());
    }

    @Test
    public void testCreateReadUpdateDeleteBooking() {
        // Create
        Booking booking = new Booking("John", "Doe", 120, true,
                new BookingDates("2025-01-01", "2025-01-10"), "Breakfast");
        Response createResponse = bookingClient.createBooking(booking);
        createResponse.then().statusCode(200).body("booking.firstname", equalTo("John"));

        int bookingId = createResponse.then().extract().path("bookingid");

        // Read
        bookingClient.getBooking(bookingId).then().statusCode(200).body("lastname", equalTo("Doe"));

        // Update
        Booking updatedBooking = new Booking("Jane", "Doe", 150, false,
                new BookingDates("2025-02-01", "2025-02-15"), "Lunch");
        bookingClient.updateBooking(bookingId, updatedBooking, token)
                .then().statusCode(200).body("firstname", equalTo("Jane"));

        // Delete
        bookingClient.deleteBooking(bookingId, token).then().statusCode(201);

        // Verify Deletion
        bookingClient.getBooking(bookingId).then().statusCode(404);
    }
}
